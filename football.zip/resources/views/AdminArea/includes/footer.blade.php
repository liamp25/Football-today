<footer class="footer mt-auto text-center">
    <div class="copyright bg-white">
        <p>
            &copy; <span id="copy-year">2021</span> Copyright Football-Today
        </p>
    </div>
    <script>
        var d = new Date();
        var year = d.getFullYear();
        document.getElementById("copy-year").innerHTML = year;

    </script>
</footer>
