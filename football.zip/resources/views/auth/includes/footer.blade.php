<div class="copyright pl-0">
    <p class="text-center">&copy; <span id="copy-year">2021</span> Copyright Football-Today
    </p>
</div>
<script>
    var d = new Date();
    var year = d.getFullYear();
    document.getElementById("copy-year").innerHTML = year;

</script>
