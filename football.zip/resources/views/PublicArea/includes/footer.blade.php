 <footer>
     <div class="container-fluid text-center">
         <p>© {{date("Y")}} Football-Today</p>
     </div>
 </footer>
